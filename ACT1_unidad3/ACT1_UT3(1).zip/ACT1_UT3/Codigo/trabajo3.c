
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int edad,antiguedad,nombre;
int main(){
printf("ingresar edad :");
scanf("%d",&edad);
printf("ingresar antiguedad :");
scanf("%d",&antiguedad);

    if((edad>=60)&&(antiguedad>=25))
       printf("jubilado por antiguedad adulta");
    else if((edad<60)&&(antiguedad>=25)){
      printf("jubilado por antiguedad joven");
    }
    else if((edad>60)&&(antiguedad>=0)){
        printf("jubilado por edad");
    }else{
      printf("no cuenta con jubilacion");
    }
  fflush(stdin);
  getchar();
   return 0;
}
