#include<stdio.h>
#include<stdio.h>
#include<math.h>
char nombre[20];
float monto,precio;
int main(){
  printf("introduzca el nombre del cliente:");
	scanf("%s", nombre);
	printf("introduzca el monto:");
	scanf("%f",&monto);

  if((monto>=15000)){
    precio=monto*0.75;
  }
  else if((monto>7000)&&(monto<=15000)){
    precio=monto*0.82;
  }
  else if((monto>1000)&&(monto<=7000)){
    precio=monto*0.89;
  }
  else if((monto>500)&&(monto<=1000)){
    precio=monto*0.95;
  }else{
    precio = monto;
  }
  printf("\n%s\n", nombre);
  printf("Monto: %.2f\n", monto);
  printf("total a pagar: %.2f\n\n",precio);
  fflush(stdin);
  getchar();
  return 0;

}
