#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int l1,l2,l3;

int main(){
printf("ingresar longitud 1:");
scanf("%d",&l1);
printf("ingresar longitud 2:");
scanf("%d",&l2);
printf("ingresar longitud 3:");
scanf("%d",&l3);

    if((l1==l2)&&(l1==l3)&&(l3==l1)){
        printf("es un triangulo equilatero");
      }
   else if((l1<l2+l3)||(l2<l1+l3)||(l3<l1+l2)){
            if ((l1==l2)||(l1==l3)||(l2==l3)){
                printf("es un triangulo isosceles");
              }
            else{
                printf("es un triangulo escaleno");
              }
            }
  fflush(stdin);
  getchar();
	return 0;



}
