
#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	int hortra, hntra, sexo, desue=-50, hijos, hmen;
	float sueldo, edad, aumento, sueldof;
	char cad[30];

	printf("Ingrese el nombre del empleado: ");
	gets(cad);
	printf("Ingrese las horas trabajadas por semana: ");
	scanf("%d",&hortra);

	hntra= 40-hortra;

	printf(" \n\t 1 es para Mujer \n\t 2 es para Hombre ");
	printf("\n\n\t Ingrese el sexo de la persona: ");
	scanf("%d",&sexo);

	if(sexo == 1){
		sueldo=500;
		printf("Ingrese el numero de hijos que tiene: ");
		scanf("%d",&hijos);
		if(hortra < 40){
			hmen=40-hortra;
		}
		sueldof=sueldo-hmen*desue+hijos*20;
		printf("\n\n La mujer");
	}

	else{
		sueldo=700;
		printf("Ingrese la edad del trabajador");
		scanf("%f",&edad);
		if(edad >= 18 && edad < 30){
			aumento=(float)sueldo*0.10;
		}
		else if(edad <= 31 && edad >= 40){
			aumento=(float)sueldo*0.20;
		}
		else{
			aumento=(float)sueldo*0.25;
		}
		if(hortra < 40){
			hmen=40-hortra;
		}
		sueldof=sueldo-hmen*desue;
		printf("\n\n El hombre");
		}
	printf("Tendra un sueldo final de: %.2f ", sueldof);
	fflush(stdin);
	getchar();
	return 0;
	}
